﻿// Escreva um programa que leia dois números inteiros, sendo armazenados respectivamente nas variáveis A e B. O programa deverá inverter os valores entre as variáveis, de modo que o valor da variável A seja atribuído na variável B e vice-versa. Ao final exibir os valores de cada variável. 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex__09
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b, c;

            Console.Write("Digite um número inteiro para A: ");
            a = int.Parse(Console.ReadLine());
            Console.Write("Digite outro número inteiro para B: ");
            b = int.Parse(Console.ReadLine());

            c = a; // C pega o valor original de A
            a = b; // A pega o valor original de B
            b = c; // B pega o valor original de A a partir do armazenado em C

            Console.WriteLine("Os humilhados serão exaltados: o segundo valor que você pensou para B agora vale A, e o valor pensado para A agora vale aquele originalmente pensado para B. É vitória do proletariado! \n \n Provas: A = " + a + "\n B = " + b);

            Console.ReadKey();
        }
    }
}
