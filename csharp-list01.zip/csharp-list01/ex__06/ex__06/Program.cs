﻿// Escreva um programa que leia um valor em Reais (R$), leia também a cotação do Dólar, realize o cálculo da conversão de moeda (de Reais para Dólares) e exiba na tela o resultado.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex__06
{
    class Program
    {
        static void Main(string[] args)
        {
            double Real, Dolar, conversaoReal;

            Console.Write("Digite um valor em Real brasileiro: R$");
            Real = double.Parse(Console.ReadLine());
            Dolar = 0.19; // 16h25 do dia 28 mar. 2023; fonte: Google Finance

            conversaoReal = Real / Dolar;

            Console.WriteLine("R$ {0} corresponde a cerca de $ {1} na atual conversão, visto que o Real em Dólar americano está valendo em torno de R$ {2}", Real, conversaoReal, Dolar);

            Console.ReadKey();
        }
    }
}
