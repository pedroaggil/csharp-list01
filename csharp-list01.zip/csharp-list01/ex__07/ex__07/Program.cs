﻿/*

    Escreva um programa que leia o nome de duas pessoas e ao final exiba: 
        •	O nome das duas pessoas com todos os caracteres maiúsculos 
        •	A quantidade de caracteres de cada nome 
        •	Apenas os três primeiros caracteres de cada nome

 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex__07
{
    class Program
    {
        static void Main(string[] args)
        {
            string nome1, nome2;

            Console.Write("Digite o primeiro nome: ");
            nome1 = Console.ReadLine().ToUpper();
            Console.Write("Digite o segundo nome: ");
            nome2 = Console.ReadLine().ToUpper();

            Console.WriteLine("\n O nome '" + nome1 + "' tem exatamente " + nome1.Length + " caracteres, e suas três letras iniciais são '" + nome1.Substring(0, 3) + "'. \n \n O nome '" + nome2 + "' tem exatamente " + nome2.Length + " caracteres, e suas três letras iniciais são '" + nome2.Substring(0, 3) + "'.");

            Console.ReadKey();
        }
    }
}
