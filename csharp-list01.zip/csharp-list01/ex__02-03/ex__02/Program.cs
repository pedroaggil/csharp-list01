﻿/*

    2. Escreva um programa que leia um número inteiro, calcule e exiba o resultado do dobro deste número.

    3. Escreva um programa que leia um número inteiro, calcule e exiba esse o resultado do quadrado desse número.

 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex__02_03
{
    class Program
    {
        static void Main(string[] args)
        {
            int x, dobro, quadrado;

            Console.Write("Digite o valor para um número inteiro: ");
            x = int.Parse(Console.ReadLine());

            dobro = x * 2;
            quadrado = x * x;

            Console.WriteLine("O número que você digitou pode ser calculado das seguintes maneiras:\n Número: " + x + "\n Dobro: " + dobro + "\n Quadrado: " + quadrado);

            Console.ReadKey();
        }
    }
}
