﻿// Escreva um programa que leia um valor em Reais (R$), leia também a cotação do Dólar e do Euro, realize o cálculo das respectivas conversões de moedas (de Reais para Dólares e de Reais para Euros) e exiba os resultados na tela. 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex__08
{
    class Program
    {
        static void Main(string[] args)
        {
            double Real, Dolar, Euro, conversaoDolarReal, conversaoEuroReal;

            Console.Write("Digite um valor em Real brasileiro: R$");
            Real = double.Parse(Console.ReadLine());
            Dolar = 0.19; // 16h25 do dia 28 mar. 2023; fonte: Google Finance
            Euro = 0.18; // 16h25 do dia 28 mar. 2023; fonte: Google Finance

            conversaoDolarReal = Real / Dolar;
            conversaoEuroReal = Real / Euro;

            Console.WriteLine("R$ " + Real + " corresponde a cerca de $ " + conversaoDolarReal + " e € " + conversaoEuroReal + " na atual conversão.");

            Console.ReadKey();
        }
    }
}
