﻿// Escreva um programa que calcule e exiba o resultado da seguinte expressão matemática: (Dica: O usuário deverá informar os valores para as variáveis A, B e C): `A² * 5 – C / (B – A % 4)`

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex__04
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b, c, res;

            Console.Write("Diga o valor do primeiro número: ");
            a = int.Parse(Console.ReadLine());
            Console.Write("Diga o valor do segundo número: ");
            b = int.Parse(Console.ReadLine());
            Console.Write("Diga o valor do terceiro número: ");
            c = int.Parse(Console.ReadLine());

            res = ((a * a) * 5 - c / (b - a % 4));

            Console.WriteLine("Será calculado a seguinte expressão com base nos valores digitados: \n `A² * 5 – C / (B – A % 4)`\nO resultado é: " + res);

            Console.ReadKey();
        }
    }
}
