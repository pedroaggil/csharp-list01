﻿
// Escreva um programa que armazene em variáveis o seu nome, sua idade e a cidade onde reside. Na sequência exiba o conteúdo dessas variáveis na tela.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex__01
{
    class Program
    {
        static void Main(string[] args)
        {
            string nome, cidade;
            int idade;

            nome = "Pedro Gil";
            cidade = "Itanhaém / SP";
            idade = 18;

            Console.WriteLine(nome + ", meus parabéns por morar na linda cidade de " + cidade + " na jovial idade de apenas " + idade + "! :D");

            Console.ReadKey();
        }
    }
}