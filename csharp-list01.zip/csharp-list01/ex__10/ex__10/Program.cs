﻿/*

    Escreva um programa que calcule a expressão lógica que segue, sendo que o usuário deverá informar os valores (números inteiros) para as variáveis. 

    `((X >= Y) AND (Z <=X)) OR ((X == W) AND (Y == Z)) OR (NOT(X != W))`

 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex__10
{
    class Program
    {
        static void Main(string[] args)
        {
            int w, x, y, z;

            Console.Write("Digite um número inteiro para W: ");
            w = int.Parse(Console.ReadLine());
            Console.Write("Digite um número inteiro para X: ");
            x = int.Parse(Console.ReadLine());
            Console.Write("Digite um número inteiro para Y: ");
            y = int.Parse(Console.ReadLine());
            Console.Write("Digite um número inteiro para Z: ");
            z = int.Parse(Console.ReadLine());

            if (((x >= y) && (z <= x)) || ((x == w) && (y == z)) || (!(x != w)))
            {
                Console.WriteLine("Olha, segundo a expressão lógica `((X >= Y) AND (Z <=X)) OR ((X == W) AND (Y == Z)) OR (NOT(X != W))`, entre os valores que você selecionou, alguma destas condições se mostrou verdadeira.");
            }
            else
            {
                Console.WriteLine("Olha, segundo a expressão lógica `((X >= Y) AND (Z <=X)) OR ((X == W) AND (Y == Z)) OR (NOT(X != W))`, entre os valores que você selecionou, essas condições se mostraram falsas.");
            }

            Console.ReadKey();
        }
    }
}
