﻿// Escreva um programa que leia a idade de uma pessoa e deverá ser exibido na tela, se esta pessoa é maior ou menor de idade (considerar 18 anos para maior idade). (Dica: Usar operadores ternários)

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex__05
{
    class Program
    {
        static void Main(string[] args)
        {
            int idade, febem;

            Console.Write("Quantos anos você tem? ");
            idade = int.Parse(Console.ReadLine());

            if (idade >= 18)
            {
                Console.WriteLine("Legal! Já pode ser preso(a).");
            }
            else
            {
                febem = 18 - idade;
                string tempo = (febem != 1) ? febem.ToString() + " anos!" : " meses!";
                Console.Write("Bem, você não será preso(a) mas talvez vá para a Febem; aproveite bem os próximos " + tempo);
            }

            Console.ReadKey();
        }
    }
}
